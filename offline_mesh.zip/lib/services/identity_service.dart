import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'package:cryptography/cryptography.dart';
import 'package:uuid/uuid.dart';
import '../core/packet.dart';
import '../data/database_helper.dart';

class IdentityService {
  static final IdentityService I = IdentityService._();
  IdentityService._();
  final _algo = Ed25519();
  late SimpleKeyPair keyPair;
  late String id, pkB64;
  String username = '', bio = '';
  Uint8List? dp;
  bool onboarded = false;

  static const _adj = ['Cyber', 'Silent', 'Neon', 'Swift', 'Lunar', 'Pixel', 'Iron', 'Echo'];
  static const _noun = ['Falcon', 'Wolf', 'Tiger', 'Comet', 'Raven', 'Nomad', 'Ghost', 'Lynx'];
  static String randomUsername() {
    final r = Random.secure();
    return '${_adj[r.nextInt(_adj.length)]}${_noun[r.nextInt(_noun.length)]}_${100 + r.nextInt(900)}';
  }

  /// Loads or creates the permanent offline identity (Ed25519 + UUID).
  Future<void> init() async {
    final db = DatabaseHelper.I;
    final seed = await db.getProfile<Uint8List>('seed');
    final pub = await db.getProfile<Uint8List>('pub');
    final uid = await db.getProfile<Uint8List>('uuid');
    if (seed == null || pub == null || uid == null) {
      final kp = await _algo.newKeyPair();
      final s = Uint8List.fromList(await kp.extractPrivateKeyBytes());
      final p = (await kp.extractPublicKey()).bytes;
      final u = const Uuid().v4();
      await db.setProfile('seed', s);
      await db.setProfile('pub', Uint8List.fromList(p));
      await db.setProfile('uuid', Uint8List.fromList(utf8.encode(u)));
      keyPair = SimpleKeyPairData(s, publicKey: SimplePublicKey(p, type: KeyPairType.ed25519), type: KeyPairType.ed25519);
      id = u; pkB64 = base64Encode(p);
      username = randomUsername();
    } else {
      keyPair = SimpleKeyPairData(seed, publicKey: SimplePublicKey(pub, type: KeyPairType.ed25519), type: KeyPairType.ed25519);
      id = utf8.decode(uid); pkB64 = base64Encode(pub);
      username = utf8.decode(await db.getProfile<Uint8List>('username') ?? Uint8List(0));
      bio = utf8.decode(await db.getProfile<Uint8List>('bio') ?? Uint8List(0));
      dp = await db.getProfile<Uint8List>('dp');
      onboarded = (await db.getProfile<Uint8List>('onboarded')) != null;
    }
  }

  Future<void> saveProfile({String? name, String? newBio, Uint8List? newDp, bool finish = false}) async {
    final db = DatabaseHelper.I;
    if (name != null) { username = name; await db.setProfile('username', Uint8List.fromList(utf8.encode(name))); }
    if (newBio != null) { bio = newBio; await db.setProfile('bio', Uint8List.fromList(utf8.encode(newBio))); }
    if (newDp != null) { dp = newDp; await db.setProfile('dp', newDp); }
    if (finish) { onboarded = true; await db.setProfile('onboarded', Uint8List.fromList([1])); }
  }

  Future<String> sign(List<int> data) async =>
      base64Encode((await _algo.sign(data, keyPair: keyPair)).bytes);

  Future<bool> verify(List<int> data, String sigB64, String pkB64) async {
    try {
      return await _algo.verify(data, signature: Signature(base64Decode(sigB64),
          publicKey: SimplePublicKey(base64Decode(pkB64), type: KeyPairType.ed25519)));
    } catch (_) { return false; }
  }

  Future<Packet> build(String type, Map<String, dynamic> payload, {String? dst, int ttl = 16}) async {
    final p = Packet(id: const Uuid().v4(), type: type, src: id, srcName: username, pk: pkB64,
        dst: dst, ttl: ttl, ts: DateTime.now().millisecondsSinceEpoch, payload: payload);
    p.sig = await sign(p.signable());
    return p;
  }
}
