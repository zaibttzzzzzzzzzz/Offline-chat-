import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart' show ConflictAlgorithm;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import '../core/packet.dart';
import '../data/database_helper.dart';
import 'identity_service.dart';
import 'mesh_router_engine.dart';
import 'nearby_hybrid_service.dart';
import 'serverless_webrtc_manager.dart';

final navKey = GlobalKey<NavigatorState>();

/// Application brain: wires transport -> router -> protocol handlers -> SQLite -> UI.
class MeshController extends ChangeNotifier {
  final id = IdentityService.I, db = DatabaseHelper.I;
  late final NearbyHybridService link = NearbyHybridService();
  late final MeshRouterEngine router = MeshRouterEngine(link);
  late final ServerlessWebRTCManager rtc = ServerlessWebRTCManager(router);
  bool dark = false, tower = true, started = false;
  Timer? _hello;
  final Set<String> pendingOut = {};
  final Map<String, Packet> incomingRequests = {};   // userId -> FRIEND_REQ packet
  Packet? incomingCall;
  final List<String> callLog = [];

  Future<void> init() async {
    final sp = await SharedPreferences.getInstance();
    dark = sp.getBool('dark') ?? false; tower = sp.getBool('tower') ?? true;
    router.towerMode = tower;
    router.delivered.listen(_handle);
    router.onPeerUp = () { _hello?.cancel(); announce(); router.flushOutbox(); };
    link.onPeersChanged.listen((_) => notifyListeners());
    for (final f in await db.friends(status: 'pending_out')) { pendingOut.add(f['id'] as String); }
    notifyListeners();
  }

  Future<void> startMesh() async {
    if (started) return;
    await NearbyHybridService.requestPermissions();
    await link.start(id.username);
    started = true;
    _hello = Timer.periodic(const Duration(seconds: 20), (_) => announce());
    notifyListeners();
  }

  Future<void> announce() async =>
      router.send(await id.build(T.hello, {'bio': id.bio}, ttl: 8));

  Future<void> setDark(bool v) async {
    dark = v; (await SharedPreferences.getInstance()).setBool('dark', v); notifyListeners();
  }
  Future<void> setTower(bool v) async {
    tower = v; router.towerMode = v;
    (await SharedPreferences.getInstance()).setBool('tower', v); notifyListeners();
  }

  /// All nodes heard on the mesh, nearest first.
  List<({String id, String name, int hops})> get discovered => (router.routing.entries
      .map((e) => (id: e.key, name: router.peerNames[e.key] ?? 'Unknown', hops: e.value.hops)).toList()
    ..sort((a, b) => a.hops.compareTo(b.hops)));

  // ---------- Compression ----------
  static Future<Uint8List> compressDp(String path) async {
    var q = 80; Uint8List? out;
    while (q >= 20) {
      out = await FlutterImageCompress.compressWithFile(path, minWidth: 256, minHeight: 256,
          format: CompressFormat.webp, quality: q);
      if (out != null && out.length < 40 * 1024) return out;
      q -= 15;
    }
    return out ?? Uint8List(0);
  }

  // ---------- Friends ----------
  Future<void> sendFriendRequest(String uid, String name) async {
    await db.upsertFriend({'id': uid, 'username': name, 'status': 'pending_out', 'added': _now});
    pendingOut.add(uid); notifyListeners();
    router.send(await id.build(T.friendReq, {'bio': id.bio, 'dp': id.dp == null ? null : base64Encode(id.dp!)}, dst: uid));
  }

  Future<void> acceptRequest(String uid) async {
    final p = incomingRequests.remove(uid); if (p == null) return;
    await _saveFriend(p, 'accepted');
    router.send(await id.build(T.friendAcc, {'bio': id.bio, 'dp': id.dp == null ? null : base64Encode(id.dp!)}, dst: uid));
    notifyListeners();
  }

  Future<void> rejectRequest(String uid) async {
    incomingRequests.remove(uid);
    router.send(await id.build(T.friendRej, {}, dst: uid)); notifyListeners();
  }

  Future<void> _saveFriend(Packet p, String status) => db.upsertFriend({
    'id': p.src, 'username': p.srcName, 'bio': p.payload['bio'] ?? '',
    'dp': p.payload['dp'] == null ? null : base64Decode(p.payload['dp']), 'pk': p.pk,
    'status': status, 'added': _now});

  int get _now => DateTime.now().millisecondsSinceEpoch;

  // ---------- Messaging ----------
  Future<List<String>> _members(String chatId, bool group) async {
    if (!group) return [chatId];
    final g = (await db.groups()).firstWhere((g) => g['id'] == chatId);
    return List<String>.from(jsonDecode(g['members'] as String))..remove(id.id);
  }

  Future<bool> canSend(String gid) async {
    final g = (await db.groups()).firstWhere((g) => g['id'] == gid);
    final p = await db.perms(gid);
    return g['admin'] == id.id || (p?['members_send'] ?? 1) == 1;
  }

  Future<void> sendMessage(String chatId, bool group, String body,
      {String kind = 'text', Uint8List? file, String? fileName}) async {
    final mid = const Uuid().v4();
    String? path;
    if (file != null) { path = await _saveFile(mid, fileName ?? 'file', file); }
    await db.insertMessage({'msg_id': mid, 'chat_id': chatId, 'sender': id.id, 'sender_name': id.username,
      'body': body, 'kind': kind, 'file_path': path, 'ts': _now, 'mine': 1, 'state': 0, 'unread': 0});
    for (final m in await _members(chatId, group)) {
      final pkt = await id.build(T.msg, {'mid': mid, 'chat': group ? chatId : id.id, 'group': group,
        'body': body, 'kind': kind, 'fname': fileName, 'file': file == null ? null : base64Encode(file)}, dst: m);
      router.send(pkt);
    }
    notifyListeners();
  }

  Future<String> _saveFile(String mid, String name, Uint8List bytes) async {
    final dir = await getApplicationDocumentsDirectory();
    final f = File('${dir.path}/${mid}_$name'); await f.writeAsBytes(bytes); return f.path;
  }

  Future<void> markRead(String chatId) async {
    final rows = await db.messages(chatId);
    await db.markChatRead(chatId);
    for (final m in rows.where((m) => m['mine'] == 0 && m['unread'] == 1)) {
      router.send(await id.build(T.read, {'mid': m['msg_id']}, dst: m['sender'] as String, ttl: 12));
    }
    notifyListeners();
  }

  // ---------- Groups ----------
  Future<void> createGroup(String name, List<String> members, {required bool add, required bool send,
      required bool call, Uint8List? icon}) async {
    final gid = const Uuid().v4(); final all = [...members, id.id];
    final perms = {'add': add, 'send': send, 'call': call};
    await db.upsertGroup({'id': gid, 'name': name, 'icon': icon, 'admin': id.id,
      'members': jsonEncode(all), 'created': _now}, _permRow(gid, perms, 1));
    for (final m in members) {
      router.send(await id.build(T.groupInit, {'gid': gid, 'name': name, 'admin': id.id, 'members': all,
        'perms': perms, 'ver': 1, 'icon': icon == null ? null : base64Encode(icon)}, dst: m));
    }
    notifyListeners();
  }

  Map<String, Object?> _permRow(String gid, Map perms, int ver) => {'group_id': gid,
    'members_add': perms['add'] == true ? 1 : 0, 'members_send': perms['send'] == true ? 1 : 0,
    'members_call': perms['call'] == true ? 1 : 0, 'sig': '', 'ver': ver};

  /// Admin live-toggles; signed packet is verified by every member and applied only if src == admin.
  Future<void> updatePermissions(String gid, {required bool add, required bool send, required bool call}) async {
    final old = await db.perms(gid); final ver = ((old?['ver'] as int?) ?? 1) + 1;
    final perms = {'add': add, 'send': send, 'call': call};
    await (await db.db).insert('group_permissions', _permRow(gid, perms, ver), conflictAlgorithm: ConflictAlgorithm.replace);
    for (final m in await _members(gid, true)) {
      router.send(await id.build(T.groupPerm, {'gid': gid, 'perms': perms, 'ver': ver}, dst: m));
    }
    notifyListeners();
  }

  Future<void> addMemberToGroup(String gid, String friendId) async {
    final g = (await db.groups()).firstWhere((g) => g['id'] == gid);
    final p = await db.perms(gid);
    if (g['admin'] != id.id && (p?['members_add'] ?? 0) == 0) return;
    final members = List<String>.from(jsonDecode(g['members'] as String));
    if (members.contains(friendId)) return;
    members.add(friendId);
    await (await db.db).update('groups', {'members': jsonEncode(members)}, where: 'id=?', whereArgs: [gid]);
    final perms = {'add': p?['members_add'] == 1, 'send': p?['members_send'] == 1, 'call': p?['members_call'] == 1};
    for (final m in members.where((m) => m != id.id)) {
      router.send(await id.build(T.groupInit, {'gid': gid, 'name': g['name'], 'admin': g['admin'],
        'members': members, 'perms': perms, 'ver': p?['ver'] ?? 1, 'icon': null}, dst: m));
    }
    notifyListeners();
  }

  // ---------- Status ----------
  Future<void> postStatus({String? text, Uint8List? image, required bool global, List<String> to = const []}) async {
    final sid = const Uuid().v4(); final ts = _now;
    await db.insertStatus({'id': sid, 'author': id.id, 'author_name': id.username, 'text': text, 'image': image,
      'ts': ts, 'scope': global ? 'global' : 'private', 'hops': 0});
    final payload = {'sid': sid, 'text': text, 'image': image == null ? null : base64Encode(image), 'scope': global ? 'global' : 'private'};
    if (global) { router.send(await id.build(T.status, payload, ttl: 64)); }   // epidemic flood
    else { for (final f in to) { router.send(await id.build(T.status, payload, dst: f)); } }
    notifyListeners();
  }

  // ---------- Channels ----------
  Future<void> createChannel(String name) async {
    final cid = const Uuid().v4();
    await db.upsertChannel({'id': cid, 'name': name, 'owner': id.id, 'pk': id.pkB64, 'followed': 1, 'mine': 1});
    router.send(await id.build(T.chanAnn, {'cid': cid, 'name': name}, ttl: 64)); notifyListeners();
  }
  Future<void> postToChannel(String cid, String body) async {
    final pid = const Uuid().v4();
    await db.insertChannelPost({'id': pid, 'channel_id': cid, 'body': body, 'ts': _now});
    router.send(await id.build(T.chanPost, {'cid': cid, 'pid': pid, 'body': body}, ttl: 64));
  }
  Future<void> follow(String cid, bool f) async { await db.followChannel(cid, f); notifyListeners(); }

  // ---------- Incoming protocol ----------
  Future<bool> _isFriend(String uid) async =>
      (await db.friends(status: 'accepted')).any((f) => f['id'] == uid);

  Future<void> _handle(Packet p) async {
    switch (p.type) {
      case T.hello: notifyListeners(); break;
      case T.friendReq:
        incomingRequests[p.src] = p;
        await db.upsertFriend({'id': p.src, 'username': p.srcName, 'bio': p.payload['bio'] ?? '',
          'dp': p.payload['dp'] == null ? null : base64Decode(p.payload['dp']), 'pk': p.pk, 'status': 'pending_in', 'added': _now});
        break;
      case T.friendAcc:
        if (pendingOut.remove(p.src)) await _saveFriend(p, 'accepted'); break;
      case T.friendRej:
        pendingOut.remove(p.src); break;
      case T.profile:
        if (await _isFriend(p.src)) await _saveFriend(p, 'accepted'); break;
      case T.msg: await _onMsg(p); break;
      case T.ack: await db.setMsgState(p.payload['mid'], 1); break;
      case T.read: await db.setMsgState(p.payload['mid'], 2); break;
      case T.groupInit:
        if (p.src != p.payload['admin'] && !await _memberMayAdd(p)) break;
        final pr = p.payload['perms'] as Map;
        await db.upsertGroup({'id': p.payload['gid'], 'name': p.payload['name'],
          'icon': p.payload['icon'] == null ? null : base64Decode(p.payload['icon']),
          'admin': p.payload['admin'], 'members': jsonEncode(p.payload['members']), 'created': p.ts},
          _permRow(p.payload['gid'], pr, p.payload['ver'] ?? 1));
        break;
      case T.groupPerm:
        final g = (await db.groups()).where((g) => g['id'] == p.payload['gid']);
        final cur = await db.perms(p.payload['gid']);
        if (g.isNotEmpty && g.first['admin'] == p.src && (p.payload['ver'] as int) > ((cur?['ver'] as int?) ?? 0)) {
          await (await db.db).insert('group_permissions', _permRow(p.payload['gid'], p.payload['perms'], p.payload['ver']),
              conflictAlgorithm: ConflictAlgorithm.replace);
        }
        break;
      case T.status:
        final priv = p.payload['scope'] == 'private';
        if (priv && !await _isFriend(p.src)) break;
        await db.insertStatus({'id': p.payload['sid'], 'author': p.src, 'author_name': p.srcName,
          'text': p.payload['text'], 'image': p.payload['image'] == null ? null : base64Decode(p.payload['image']),
          'ts': p.ts, 'scope': p.payload['scope'], 'hops': p.hops});
        break;
      case T.chanAnn:
        await db.upsertChannel({'id': p.payload['cid'], 'name': p.payload['name'], 'owner': p.src, 'pk': p.pk, 'followed': 0, 'mine': 0}); break;
      case T.chanPost:
        final ch = (await db.channels()).where((c) => c['id'] == p.payload['cid'] && c['owner'] == p.src && c['followed'] == 1);
        if (ch.isNotEmpty) await db.insertChannelPost({'id': p.payload['pid'], 'channel_id': p.payload['cid'], 'body': p.payload['body'], 'ts': p.ts});
        break;
      case T.callOffer:
        if (p.payload['group'] == true) break;
        incomingCall = p; callLog.insert(0, '${p.srcName} • incoming'); break;
      case T.callAnswer: await rtc.onAnswer(p); break;
      case T.callIce: await rtc.onIce(p); break;
      case T.callEnd:
        await rtc.end(notify: false); incomingCall = null;
        navKey.currentState?.popUntil((r) => r.isFirst); break;
    }
    notifyListeners();
  }

  Future<bool> _memberMayAdd(Packet p) async {
    final perms = await db.perms(p.payload['gid']);
    return perms?['members_add'] == 1;
  }

  Future<void> _onMsg(Packet p) async {
    final group = p.payload['group'] == true; final chat = p.payload['chat'] as String;
    if (group) {
      final g = (await db.groups()).where((g) => g['id'] == chat);
      if (g.isEmpty) return;
      final perms = await db.perms(chat);
      if (g.first['admin'] != p.src && (perms?['members_send'] ?? 1) == 0) return; // enforce chat lock
    } else if (!await _isFriend(p.src)) { return; }
    String? path;
    if (p.payload['file'] != null) {
      path = await _saveFile(p.payload['mid'], p.payload['fname'] ?? 'file', base64Decode(p.payload['file']));
    }
    await db.insertMessage({'msg_id': p.payload['mid'], 'chat_id': chat, 'sender': p.src, 'sender_name': p.srcName,
      'body': p.payload['body'], 'kind': p.payload['kind'], 'file_path': path, 'ts': p.ts, 'mine': 0, 'state': 0, 'unread': 1});
    router.send(await id.build(T.ack, {'mid': p.payload['mid']}, dst: p.src, ttl: 12));
  }

  Future<void> broadcastProfile() async {
    for (final f in await db.friends(status: 'accepted')) {
      router.send(await id.build(T.profile, {'bio': id.bio, 'dp': id.dp == null ? null : base64Encode(id.dp!)}, dst: f['id'] as String));
    }
  }
}
