import 'dart:async';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import '../core/packet.dart';
import 'identity_service.dart';
import 'mesh_router_engine.dart';

/// Serverless WebRTC: iceServers is STRICTLY empty. SDP/ICE travel as mesh packets.
/// Only host candidates are gathered, so media works when peers share a direct L2 path
/// (same Wi-Fi Direct group / LAN); it cannot be NAT-traversed across multiple relay hops.
class ServerlessWebRTCManager {
  final MeshRouterEngine router;
  ServerlessWebRTCManager(this.router);
  RTCPeerConnection? pc;
  MediaStream? local;
  final localRenderer = RTCVideoRenderer(), remoteRenderer = RTCVideoRenderer();
  String? peerId; bool video = false;
  final _pendingIce = <RTCIceCandidate>[];
  bool _remoteSet = false;
  void Function(String state)? onState;

  Future<void> initRenderers() async { await localRenderer.initialize(); await remoteRenderer.initialize(); }

  Future<void> _create(bool withVideo) async {
    video = withVideo;
    pc = await createPeerConnection({'iceServers': [], 'sdpSemantics': 'unified-plan'});
    local = await navigator.mediaDevices.getUserMedia({
      'audio': {'echoCancellation': true, 'noiseSuppression': true},
      'video': withVideo ? {'facingMode': 'user', 'width': {'ideal': 640, 'max': 640},
        'height': {'ideal': 360, 'max': 480}, 'frameRate': {'ideal': 15, 'max': 15}} : false,
    });
    localRenderer.srcObject = local;
    for (final t in local!.getTracks()) { await pc!.addTrack(t, local!); }
    pc!.onTrack = (e) { if (e.streams.isNotEmpty) remoteRenderer.srcObject = e.streams[0]; };
    pc!.onIceCandidate = (c) async {
      if (c.candidate == null || peerId == null) return;
      router.send(await IdentityService.I.build(T.callIce, c.toMap().cast<String, dynamic>(), dst: peerId, ttl: 8));
    };
    pc!.onConnectionState = (s) => onState?.call(s.name);
  }

  /// ~400kbps video cap via SDP bandwidth line (protects relay phones).
  String _cap(String sdp) => sdp.replaceFirst(RegExp(r'(m=video[^\r\n]*\r\n)(c=[^\r\n]*\r\n)?'), r'$1$2b=AS:400' '\r\n');

  Future<void> startCall(String peer, {required bool video}) async {
    peerId = peer; await _create(video);
    final o = await pc!.createOffer();
    final capped = RTCSessionDescription(_cap(o.sdp!), o.type);
    await pc!.setLocalDescription(capped);
    router.send(await IdentityService.I.build(T.callOffer, {'sdp': capped.sdp, 'type': capped.type, 'video': video}, dst: peer, ttl: 8));
  }

  Future<void> acceptOffer(Packet p) async {
    peerId = p.src; await _create(p.payload['video'] == true);
    await pc!.setRemoteDescription(RTCSessionDescription(p.payload['sdp'], p.payload['type']));
    _remoteSet = true; await _drainIce();
    final a = await pc!.createAnswer();
    final capped = RTCSessionDescription(_cap(a.sdp!), a.type);
    await pc!.setLocalDescription(capped);
    router.send(await IdentityService.I.build(T.callAnswer, {'sdp': capped.sdp, 'type': capped.type}, dst: peerId, ttl: 8));
  }

  Future<void> onAnswer(Packet p) async {
    await pc?.setRemoteDescription(RTCSessionDescription(p.payload['sdp'], p.payload['type']));
    _remoteSet = true; await _drainIce();
  }

  Future<void> onIce(Packet p) async {
    final c = RTCIceCandidate(p.payload['candidate'], p.payload['sdpMid'], p.payload['sdpMLineIndex']);
    if (_remoteSet) { await pc?.addCandidate(c); } else { _pendingIce.add(c); }
  }

  Future<void> _drainIce() async { for (final c in _pendingIce) { await pc?.addCandidate(c); } _pendingIce.clear(); }

  void setMute(bool m) { for (final t in local?.getAudioTracks() ?? []) { t.enabled = !m; } }
  Future<void> setSpeaker(bool on) => Helper.setSpeakerphoneOn(on);
  Future<void> switchCamera() async {
    final t = local?.getVideoTracks();
    if (t != null && t.isNotEmpty) await Helper.switchCamera(t.first);
  }

  Future<void> end({bool notify = true}) async {
    if (notify && peerId != null) {
      router.send(await IdentityService.I.build(T.callEnd, {}, dst: peerId, ttl: 8));
    }
    for (final t in local?.getTracks() ?? []) { await t.stop(); }
    await local?.dispose(); await pc?.close();
    pc = null; local = null; peerId = null; _remoteSet = false; _pendingIce.clear();
    localRenderer.srcObject = null; remoteRenderer.srcObject = null;
  }
}
