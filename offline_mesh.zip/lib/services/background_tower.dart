import 'dart:async';
import 'dart:ui';
import 'package:flutter_background_service/flutter_background_service.dart';

/// Android Foreground Service ("Mesh Tower") so the OS keeps the process (and Nearby links) alive.
Future<void> initTowerService() async {
  await FlutterBackgroundService().configure(
    androidConfiguration: AndroidConfiguration(
      onStart: _onStart, autoStart: false, isForegroundMode: true,
      notificationChannelId: 'mesh_tower', initialNotificationTitle: 'Mesh Tower active',
      initialNotificationContent: 'Relaying messages for nearby devices',
      foregroundServiceTypes: [AndroidForegroundType.connectedDevice],
    ),
    iosConfiguration: IosConfiguration(autoStart: false),
  );
}

@pragma('vm:entry-point')
void _onStart(ServiceInstance service) async {
  DartPluginRegistrant.ensureInitialized();
  service.on('stop').listen((_) => service.stopSelf());
}

Future<void> setTowerService(bool on) async {
  final s = FlutterBackgroundService();
  if (on) { if (!await s.isRunning()) await s.startService(); } else { s.invoke('stop'); }
}
