import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'package:nearby_connections/nearby_connections.dart';
import 'package:permission_handler/permission_handler.dart';

class Endpoint { final String id, name; Endpoint(this.id, this.name); }

/// Google Nearby Connections, STRATEGY_P2P_CLUSTER (M-to-N). Nearby discovers over BLE and
/// automatically upgrades each connection to Bluetooth Classic / Wi-Fi Direct / hotspot for speed.
/// Payloads > ~30KB are chunked here at the transport layer.
class NearbyHybridService {
  static const serviceId = 'com.offlinemesh.tower';
  static const _chunk = 28 * 1024;
  final _strategy = Strategy.P2P_CLUSTER;
  final Map<String, Endpoint> connected = {};
  final Map<String, String> _pendingNames = {};
  final Map<String, Map<String, List<String?>>> _assembly = {};
  final _rx = StreamController<({String from, Uint8List data})>.broadcast();
  final _peers = StreamController<Map<String, Endpoint>>.broadcast();
  Stream<({String from, Uint8List data})> get onData => _rx.stream;
  Stream<Map<String, Endpoint>> get onPeersChanged => _peers.stream;
  void Function(String endpointId)? onPeerConnected;
  String _name = 'node';
  bool running = false;

  static Future<bool> requestPermissions() async {
    final r = await [Permission.location, Permission.bluetoothScan, Permission.bluetoothAdvertise,
      Permission.bluetoothConnect, Permission.nearbyWifiDevices, Permission.notification,
      Permission.microphone, Permission.camera].request();
    return r[Permission.bluetoothConnect]?.isGranted != false && r[Permission.location]?.isGranted != false;
  }

  Future<void> start(String nodeName) async {
    if (running) return;
    _name = nodeName; running = true;
    await Nearby().startAdvertising(_name, _strategy,
        onConnectionInitiated: _onInit, onConnectionResult: _onResult,
        onDisconnected: _onDisc, serviceId: serviceId);
    await Nearby().startDiscovery(_name, _strategy, serviceId: serviceId,
        onEndpointFound: (id, name, sid) {
          // Deterministic tie-break so only ONE side requests (avoids simultaneous-connect clash).
          if (!connected.containsKey(id) && _name.compareTo(name) < 0) {
            Nearby().requestConnection(_name, id,
                onConnectionInitiated: _onInit, onConnectionResult: _onResult, onDisconnected: _onDisc)
                .catchError((_) => false);
          }
        },
        onEndpointLost: (id) {});
  }

  void _onInit(String id, ConnectionInfo info) {
    _pendingNames[id] = info.endpointName;
    Nearby().acceptConnection(id, onPayLoadRecieved: _onPayload, onPayloadTransferUpdate: (_, __) {});
  }

  void _onResult(String id, Status s) {
    if (s == Status.CONNECTED) {
      connected[id] = Endpoint(id, _pendingNames[id] ?? id);
      _peers.add(Map.of(connected));
      onPeerConnected?.call(id);
    }
  }

  void _onDisc(String id) { connected.remove(id); _peers.add(Map.of(connected)); }

  void _onPayload(String from, Payload p) {
    if (p.type != PayloadType.BYTES || p.bytes == null) return;
    final w = jsonDecode(utf8.decode(p.bytes!));
    if (w['n'] == 1) { _rx.add((from: from, data: base64Decode(w['d']))); return; }
    final parts = (_assembly[from] ??= {})[w['c']] ??= List<String?>.filled(w['n'], null);
    parts[w['i']] = w['d'];
    if (parts.every((e) => e != null)) {
      _assembly[from]!.remove(w['c']);
      _rx.add((from: from, data: base64Decode(parts.join())));
    }
  }

  Future<void> send(String endpointId, Uint8List data) async {
    final b64 = base64Encode(data);
    final n = (b64.length / _chunk).ceil().clamp(1, 1 << 20);
    final cid = Random().nextInt(1 << 30).toString();
    for (var i = 0; i < n; i++) {
      final part = b64.substring(i * _chunk, min(b64.length, (i + 1) * _chunk));
      await Nearby().sendBytesPayload(endpointId,
          Uint8List.fromList(utf8.encode(jsonEncode({'c': cid, 'i': i, 'n': n, 'd': part}))));
    }
  }

  Future<void> stop() async {
    running = false;
    await Nearby().stopAdvertising(); await Nearby().stopDiscovery(); await Nearby().stopAllEndpoints();
    connected.clear(); _peers.add({});
  }
}
