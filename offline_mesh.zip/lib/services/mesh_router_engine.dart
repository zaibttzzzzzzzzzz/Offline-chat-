import 'dart:async';
import 'dart:collection';
import 'dart:typed_data';
import '../core/packet.dart';
import 'identity_service.dart';
import 'nearby_hybrid_service.dart';

class Route { final String endpoint; final int hops; final DateTime seen; Route(this.endpoint, this.hops, this.seen); }

/// Multi-hop engine: msgId dedup (loop prevention), TTL decrement, dynamic routing table learned
/// from observed (src -> arrival endpoint, hops). Unknown/broadcast destinations use controlled flooding.
class MeshRouterEngine {
  final NearbyHybridService link;
  MeshRouterEngine(this.link) {
    link.onData.listen((e) => _onRaw(e.from, e.data));
    link.onPeerConnected = (_) => onPeerUp?.call();
  }
  bool towerMode = true;
  void Function()? onPeerUp;
  final routing = <String, Route>{};                 // nodeId -> best route
  final peerNames = <String, String>{};              // nodeId -> username
  final _seen = LinkedHashSet<String>();             // dedup cache (bounded)
  final _outbox = <Packet>[];                        // store-and-forward for offline targets
  final _deliver = StreamController<Packet>.broadcast();
  Stream<Packet> get delivered => _deliver.stream;
  static const _seenMax = 4000;

  bool _markSeen(String id) {
    if (!_seen.add(id)) return false;
    if (_seen.length > _seenMax) _seen.remove(_seen.first);
    return true;
  }

  Future<void> _onRaw(String from, Uint8List raw) async {
    Packet p;
    try { p = Packet.decode(raw); } catch (_) { return; }
    if (p.src == IdentityService.I.id) return;
    if (!_markSeen(p.id)) return;                                 // duplicate / loop
    if (!await IdentityService.I.verify(p.signable(), p.sig, p.pk)) return; // forged
    // Learn route (prefer fewer hops, refresh stale).
    final cur = routing[p.src];
    if (cur == null || p.hops + 1 <= cur.hops || DateTime.now().difference(cur.seen).inSeconds > 60) {
      routing[p.src] = Route(from, p.hops + 1, DateTime.now());
    }
    peerNames[p.src] = p.srcName;
    final me = IdentityService.I.id;
    final forMe = p.dst == null || p.dst == me;
    if (forMe) _deliver.add(p);
    // Relay (Tower mode): everything except packets addressed to me.
    if (towerMode && p.dst != me && p.ttl > 1) _relay(p.forwarded(), exceptEndpoint: from);
  }

  void _relay(Packet p, {String? exceptEndpoint}) {
    final data = Uint8List.fromList(p.encode());
    final r = p.dst == null ? null : routing[p.dst!];
    if (r != null && link.connected.containsKey(r.endpoint)) {
      link.send(r.endpoint, data);                                // unicast along learned route
    } else {
      for (final id in link.connected.keys) { if (id != exceptEndpoint) link.send(id, data); } // flood
      if (p.dst != null) _outbox.add(p);                          // keep for later (store-and-forward)
    }
  }

  /// Send a locally-created packet.
  Future<void> send(Packet p) async {
    _markSeen(p.id);
    _relay(p);
  }

  /// Called when a new peer link comes up: replay stored packets (epidemic sync) and expire old.
  void flushOutbox() {
    final now = DateTime.now().millisecondsSinceEpoch;
    _outbox.removeWhere((p) => now - p.ts > 24 * 3600 * 1000 || p.ttl <= 1);
    for (final p in List.of(_outbox)) {
      final r = routing[p.dst!];
      if (r != null && link.connected.containsKey(r.endpoint)) {
        link.send(r.endpoint, Uint8List.fromList(p.encode())); _outbox.remove(p);
      }
    }
  }

  int? hopsTo(String id) => routing[id]?.hops;
}
