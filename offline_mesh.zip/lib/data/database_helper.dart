import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper {
  static final DatabaseHelper I = DatabaseHelper._();
  DatabaseHelper._();
  Database? _db;

  Future<Database> get db async => _db ??= await openDatabase(
      join(await getDatabasesPath(), 'mesh.db'), version: 1, onCreate: (d, v) async {
    await d.execute('CREATE TABLE profile(k TEXT PRIMARY KEY, v BLOB)');
    // status: pending_out | pending_in | accepted
    await d.execute('''CREATE TABLE friends(id TEXT PRIMARY KEY, username TEXT, bio TEXT,
        dp BLOB, pk TEXT, status TEXT, added INTEGER)''');
    // state: 0 sent to mesh, 1 relayed/delivered, 2 read
    await d.execute('''CREATE TABLE messages(msg_id TEXT PRIMARY KEY, chat_id TEXT, sender TEXT,
        sender_name TEXT, body TEXT, kind TEXT, file_path TEXT, ts INTEGER, mine INTEGER,
        state INTEGER DEFAULT 0, unread INTEGER DEFAULT 0)''');
    await d.execute('CREATE INDEX idx_msg_chat ON messages(chat_id, ts)');
    await d.execute('''CREATE TABLE groups(id TEXT PRIMARY KEY, name TEXT, icon BLOB, admin TEXT,
        members TEXT, created INTEGER)''');
    await d.execute('''CREATE TABLE group_permissions(group_id TEXT PRIMARY KEY, members_add INTEGER,
        members_send INTEGER, members_call INTEGER, sig TEXT, ver INTEGER)''');
    // scope: global | private
    await d.execute('''CREATE TABLE statuses_24h(id TEXT PRIMARY KEY, author TEXT, author_name TEXT,
        text TEXT, image BLOB, ts INTEGER, scope TEXT, hops INTEGER)''');
    await d.execute('''CREATE TABLE channels(id TEXT PRIMARY KEY, name TEXT, owner TEXT, pk TEXT,
        followed INTEGER DEFAULT 0, mine INTEGER DEFAULT 0)''');
    await d.execute('''CREATE TABLE channel_posts(id TEXT PRIMARY KEY, channel_id TEXT, body TEXT, ts INTEGER)''');
  });

  Future<void> setProfile(String k, Object v) async =>
      (await db).insert('profile', {'k': k, 'v': v}, conflictAlgorithm: ConflictAlgorithm.replace);
  Future<V?> getProfile<V>(String k) async {
    final r = await (await db).query('profile', where: 'k=?', whereArgs: [k]);
    return r.isEmpty ? null : r.first['v'] as V?;
  }

  Future<void> upsertFriend(Map<String, Object?> f) async =>
      (await db).insert('friends', f, conflictAlgorithm: ConflictAlgorithm.replace);
  Future<List<Map<String, Object?>>> friends({String? status}) async => (await db).query('friends',
      where: status == null ? null : 'status=?', whereArgs: status == null ? null : [status]);

  Future<void> insertMessage(Map<String, Object?> m) async =>
      (await db).insert('messages', m, conflictAlgorithm: ConflictAlgorithm.ignore);
  Future<List<Map<String, Object?>>> messages(String chat) async =>
      (await db).query('messages', where: 'chat_id=?', whereArgs: [chat], orderBy: 'ts ASC');
  Future<void> setMsgState(String id, int s) async =>
      (await db).rawUpdate('UPDATE messages SET state=? WHERE msg_id=? AND state<?', [s, id, s]);
  Future<void> markChatRead(String chat) async =>
      (await db).update('messages', {'unread': 0}, where: 'chat_id=?', whereArgs: [chat]);
  Future<Map<String, Object?>?> lastMessage(String chat) async {
    final r = await (await db).query('messages', where: 'chat_id=?', whereArgs: [chat], orderBy: 'ts DESC', limit: 1);
    return r.isEmpty ? null : r.first;
  }
  Future<int> unread(String chat) async => Sqflite.firstIntValue(await (await db).rawQuery(
      'SELECT COUNT(*) FROM messages WHERE chat_id=? AND unread=1', [chat])) ?? 0;

  Future<void> upsertGroup(Map<String, Object?> g, Map<String, Object?> perm) async {
    final d = await db;
    await d.insert('groups', g, conflictAlgorithm: ConflictAlgorithm.replace);
    await d.insert('group_permissions', perm, conflictAlgorithm: ConflictAlgorithm.replace);
  }
  Future<List<Map<String, Object?>>> groups() async => (await db).query('groups');
  Future<Map<String, Object?>?> perms(String gid) async {
    final r = await (await db).query('group_permissions', where: 'group_id=?', whereArgs: [gid]);
    return r.isEmpty ? null : r.first;
  }

  Future<void> insertStatus(Map<String, Object?> s) async =>
      (await db).insert('statuses_24h', s, conflictAlgorithm: ConflictAlgorithm.ignore);
  Future<List<Map<String, Object?>>> statuses() async {
    final cutoff = DateTime.now().subtract(const Duration(hours: 24)).millisecondsSinceEpoch;
    await (await db).delete('statuses_24h', where: 'ts<?', whereArgs: [cutoff]);
    return (await db).query('statuses_24h', orderBy: 'ts DESC');
  }

  Future<void> upsertChannel(Map<String, Object?> c) async =>
      (await db).insert('channels', c, conflictAlgorithm: ConflictAlgorithm.ignore);
  Future<void> followChannel(String id, bool f) async =>
      (await db).update('channels', {'followed': f ? 1 : 0}, where: 'id=?', whereArgs: [id]);
  Future<List<Map<String, Object?>>> channels() async => (await db).query('channels');
  Future<void> insertChannelPost(Map<String, Object?> p) async =>
      (await db).insert('channel_posts', p, conflictAlgorithm: ConflictAlgorithm.ignore);
}
