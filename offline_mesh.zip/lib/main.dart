import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/theme.dart';
import 'data/database_helper.dart';
import 'services/background_tower.dart';
import 'services/identity_service.dart';
import 'services/mesh_controller.dart';
import 'ui/home_page.dart';
import 'ui/onboarding_pages.dart';

final meshProvider = ChangeNotifierProvider<MeshController>((ref) => MeshController());

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DatabaseHelper.I.db;
  await IdentityService.I.init();
  await initTowerService();
  runApp(const ProviderScope(child: App()));
}

class App extends ConsumerStatefulWidget {
  const App({super.key});
  @override ConsumerState<App> createState() => _AppState();
}

class _AppState extends ConsumerState<App> {
  bool ready = false;
  @override void initState() { super.initState(); _boot(); }
  Future<void> _boot() async {
    final m = ref.read(meshProvider);
    await m.init();
    if (IdentityService.I.onboarded) { await m.startMesh(); if (m.tower) await setTowerService(true); }
    setState(() => ready = true);
  }
  @override
  Widget build(BuildContext context) {
    final m = ref.watch(meshProvider);
    return MaterialApp(
      navigatorKey: navKey, debugShowCheckedModeBanner: false, title: 'Offline Mesh',
      theme: AppTheme.light, darkTheme: AppTheme.dark,
      themeMode: m.dark ? ThemeMode.dark : ThemeMode.light,
      home: !ready ? const Scaffold(body: Center(child: CircularProgressIndicator()))
          : IdentityService.I.onboarded ? const HomePage() : const OnboardingNamePage(),
    );
  }
}
