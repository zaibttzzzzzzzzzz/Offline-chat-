import 'dart:convert';

/// Wire packet carried over the mesh. [dst]==null means broadcast/epidemic.
class Packet {
  final String id, type, src, srcName, pk;
  final String? dst;
  final int ttl, hops, ts;
  final Map<String, dynamic> payload;
  String sig;
  Packet({required this.id, required this.type, required this.src, required this.srcName,
    required this.pk, this.dst, this.ttl = 16, this.hops = 0, required this.ts,
    this.payload = const {}, this.sig = ''});

  Packet forwarded() => Packet(id: id, type: type, src: src, srcName: srcName, pk: pk, dst: dst,
      ttl: ttl - 1, hops: hops + 1, ts: ts, payload: payload, sig: sig);

  /// Immutable fields only (ttl/hops change in transit and are NOT signed).
  List<int> signable() => utf8.encode('$id|$type|$src|${dst ?? ''}|$ts|${jsonEncode(payload)}');

  Map<String, dynamic> toJson() => {'id': id, 't': type, 's': src, 'sn': srcName, 'pk': pk, 'd': dst,
    'ttl': ttl, 'h': hops, 'ts': ts, 'p': payload, 'sig': sig};

  factory Packet.fromJson(Map<String, dynamic> j) => Packet(id: j['id'], type: j['t'], src: j['s'],
      srcName: j['sn'] ?? '', pk: j['pk'], dst: j['d'], ttl: j['ttl'], hops: j['h'], ts: j['ts'],
      payload: Map<String, dynamic>.from(j['p'] ?? {}), sig: j['sig'] ?? '');

  List<int> encode() => utf8.encode(jsonEncode(toJson()));
  static Packet decode(List<int> b) => Packet.fromJson(jsonDecode(utf8.decode(b)));
}

class T {
  static const hello = 'PEER_HELLO', friendReq = 'FRIEND_REQ', friendAcc = 'FRIEND_ACC',
      friendRej = 'FRIEND_REJ', msg = 'MSG', ack = 'ACK', read = 'READ', groupInit = 'GROUP_INIT',
      groupPerm = 'GROUP_PERM', groupAdd = 'GROUP_ADD', status = 'STATUS', chanAnn = 'CHAN_ANN',
      chanPost = 'CHAN_POST', callOffer = 'CALL_OFFER', callAnswer = 'CALL_ANSWER',
      callIce = 'CALL_ICE', callEnd = 'CALL_END', profile = 'PROFILE_UPDATE';
}
