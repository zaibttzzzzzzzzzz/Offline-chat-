import 'package:flutter/material.dart';

class AppTheme {
  static const teal = Color(0xFF008069), green = Color(0xFF25D366);
  static ThemeData light = ThemeData(
    brightness: Brightness.light, primaryColor: teal,
    colorScheme: ColorScheme.fromSeed(seedColor: teal, secondary: green),
    scaffoldBackgroundColor: Colors.white,
    appBarTheme: const AppBarTheme(backgroundColor: teal, foregroundColor: Colors.white),
  );
  static ThemeData dark = ThemeData(
    brightness: Brightness.dark, scaffoldBackgroundColor: const Color(0xFF111B21),
    colorScheme: ColorScheme.fromSeed(seedColor: teal, brightness: Brightness.dark, secondary: green),
    appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF202C33), foregroundColor: Colors.white),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(backgroundColor: Color(0xFF202C33)),
  );
  static Color chatBg(bool d) => d ? const Color(0xFF0B141A) : const Color(0xFFEFEAE2);
  static Color outBubble(bool d) => d ? const Color(0xFF005C4B) : const Color(0xFFD9FDD3);
  static Color inBubble(bool d) => d ? const Color(0xFF202C33) : Colors.white;
}
