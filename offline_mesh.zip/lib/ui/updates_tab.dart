import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import '../data/database_helper.dart';
import '../main.dart';
import '../services/identity_service.dart';
import '../services/mesh_controller.dart';
import 'widgets.dart';

Future<void> showCreateChannelDialog(BuildContext context, WidgetRef ref) async {
  final c = TextEditingController();
  await showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Create Channel'),
    content: TextField(controller: c, decoration: const InputDecoration(hintText: 'Channel name')),
    actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
      FilledButton(onPressed: () { if (c.text.trim().isNotEmpty) ref.read(meshProvider).createChannel(c.text.trim()); Navigator.pop(context); }, child: const Text('Create'))]));
}

/// PAGE 8 — Status (global/private) + Channels.
class UpdatesTab extends ConsumerWidget {
  const UpdatesTab({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final m = ref.watch(meshProvider);
    return FutureBuilder(future: Future.wait([DatabaseHelper.I.statuses(), DatabaseHelper.I.channels()]), builder: (_, s) {
      final st = (s.data?[0] ?? []) as List<Map<String, Object?>>; final ch = (s.data?[1] ?? []) as List<Map<String, Object?>>;
      return ListView(children: [
        ListTile(leading: Stack(children: [Avatar(bytes: IdentityService.I.dp, name: IdentityService.I.username),
            const Positioned(right: 0, bottom: 0, child: CircleAvatar(radius: 9, backgroundColor: Color(0xFF25D366), child: Icon(Icons.add, size: 14, color: Colors.white)))]),
          title: const Text('My Status'), subtitle: const Text('Tap to add (auto-deletes in 24h)'), onTap: () => _post(context, ref)),
        const Padding(padding: EdgeInsets.fromLTRB(16, 12, 16, 4), child: Text('Recent updates', style: TextStyle(fontWeight: FontWeight.bold))),
        for (final x in st) ListTile(
          leading: CircleAvatar(radius: 26, backgroundColor: const Color(0xFF25D366), child: Avatar(name: x['author_name'] as String)),
          title: Text(x['author_name'] as String),
          subtitle: Text('${hhmm(x['ts'] as int)} • ${x['scope'] == 'global' ? 'Global' : 'Private'} • ${hopLabel(((x['hops'] as int?) ?? 0) + 1)}'),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => StatusViewer(items: st.where((e) => e['author'] == x['author']).toList())))),
        const Divider(),
        ListTile(title: const Text('Channels', style: TextStyle(fontWeight: FontWeight.bold)),
          trailing: TextButton(onPressed: () => showCreateChannelDialog(context, ref), child: const Text('Create Channel'))),
        if (ch.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('No channels discovered yet.')),
        for (final c in ch) ListTile(leading: const CircleAvatar(child: Icon(Icons.campaign)), title: Text(c['name'] as String),
          subtitle: Text(c['mine'] == 1 ? 'Owned by you' : 'Signed broadcast'),
          onTap: c['followed'] == 1 ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChannelPage(c: c))) : null,
          trailing: c['mine'] == 1 ? null : c['followed'] == 1
              ? OutlinedButton(onPressed: () => m.follow(c['id'] as String, false), child: const Text('Following'))
              : FilledButton(onPressed: () => m.follow(c['id'] as String, true), child: const Text('Follow'))),
      ]);
    });
  }

  void _post(BuildContext context, WidgetRef ref) => showModalBottomSheet(context: context, builder: (_) => SafeArea(child: Wrap(children: [
    ListTile(leading: const Icon(Icons.public), title: const Text('Global Mesh Status'), subtitle: const Text('Everyone in the mesh via relays'),
        onTap: () { Navigator.pop(context); _compose(context, ref, global: true); }),
    ListTile(leading: const Icon(Icons.group), title: const Text('Private Friends Status'), subtitle: const Text('Choose which friends'),
        onTap: () { Navigator.pop(context); _compose(context, ref, global: false); }),
  ])));

  Future<void> _compose(BuildContext context, WidgetRef ref, {required bool global}) async {
    final text = TextEditingController(); Uint8List? img; final chosen = <String>{};
    final friends = await DatabaseHelper.I.friends(status: 'accepted');
    if (!context.mounted) return;
    await showDialog(context: context, builder: (_) => StatefulBuilder(builder: (ctx, set) => AlertDialog(
      title: Text(global ? 'Global status' : 'Private status'),
      content: SizedBox(width: double.maxFinite, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: text, decoration: const InputDecoration(hintText: 'What\'s on your mind?')),
        TextButton.icon(icon: const Icon(Icons.image), label: Text(img == null ? 'Add photo' : 'Photo added'), onPressed: () async {
          final x = await ImagePicker().pickImage(source: ImageSource.gallery); if (x == null) return;
          img = await MeshController.compressDp(x.path); set(() {});
        }),
        if (!global) for (final f in friends) CheckboxListTile(dense: true, value: chosen.contains(f['id']), title: Text(f['username'] as String),
            onChanged: (v) => set(() => v! ? chosen.add(f['id'] as String) : chosen.remove(f['id']))),
      ]))),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        FilledButton(onPressed: () {
          if (text.text.trim().isEmpty && img == null) return;
          if (!global && chosen.isEmpty) return;
          ref.read(meshProvider).postStatus(text: text.text.trim(), image: img, global: global, to: chosen.toList()); Navigator.pop(ctx);
        }, child: const Text('Post'))])));
  }
}

class StatusViewer extends StatefulWidget {
  final List<Map<String, Object?>> items;
  const StatusViewer({super.key, required this.items});
  @override State<StatusViewer> createState() => _SVState();
}
class _SVState extends State<StatusViewer> with SingleTickerProviderStateMixin {
  int i = 0; late final AnimationController ac = AnimationController(vsync: this, duration: const Duration(seconds: 5))
    ..addStatusListener((s) { if (s == AnimationStatus.completed) _next(); })..forward();
  void _next() { if (i < widget.items.length - 1) { setState(() => i++); ac.forward(from: 0); } else { Navigator.pop(context); } }
  @override void dispose() { ac.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    final x = widget.items[i];
    return Scaffold(backgroundColor: Colors.black, body: GestureDetector(onTap: _next, child: SafeArea(child: Stack(children: [
      Center(child: x['image'] != null ? Image.memory(x['image'] as Uint8List) : Padding(padding: const EdgeInsets.all(24),
          child: Text((x['text'] ?? '') as String, style: const TextStyle(color: Colors.white, fontSize: 26), textAlign: TextAlign.center))),
      if (x['image'] != null && (x['text'] ?? '') != '') Positioned(bottom: 40, left: 16, right: 16, child: Text(x['text'] as String, style: const TextStyle(color: Colors.white, fontSize: 18), textAlign: TextAlign.center)),
      Positioned(top: 8, left: 8, right: 8, child: Column(children: [
        Row(children: [for (var k = 0; k < widget.items.length; k++) Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 2),
          child: AnimatedBuilder(animation: ac, builder: (_, __) => LinearProgressIndicator(value: k < i ? 1 : k == i ? ac.value : 0, minHeight: 3))))]),
        ListTile(leading: Avatar(name: x['author_name'] as String), title: Text(x['author_name'] as String, style: const TextStyle(color: Colors.white)),
            subtitle: Text(hopLabel(((x['hops'] as int?) ?? 0) + 1), style: const TextStyle(color: Colors.white70))),
      ])),
    ]))));
  }
}

class ChannelPage extends ConsumerWidget {
  final Map<String, Object?> c;
  const ChannelPage({super.key, required this.c});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = TextEditingController();
    return Scaffold(appBar: AppBar(title: Text(c['name'] as String)), body: Column(children: [
      Expanded(child: FutureBuilder(future: DatabaseHelper.I.db.then((d) => d.query('channel_posts', where: 'channel_id=?', whereArgs: [c['id']], orderBy: 'ts DESC')),
        builder: (_, s) => ListView(children: [for (final p in (s.data ?? [])) ListTile(title: Text(p['body'] as String), subtitle: Text(hhmm(p['ts'] as int)))]))),
      if (c['mine'] == 1) SafeArea(child: Padding(padding: const EdgeInsets.all(8), child: Row(children: [
        Expanded(child: TextField(controller: t, decoration: const InputDecoration(hintText: 'Broadcast…'))),
        IconButton(icon: const Icon(Icons.send), onPressed: () { if (t.text.trim().isEmpty) return; ref.read(meshProvider).postToChannel(c['id'] as String, t.text.trim()); t.clear(); }),
      ]))),
    ]));
  }
}
