import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import '../core/theme.dart';
import '../data/database_helper.dart';
import '../main.dart';
import '../services/identity_service.dart';
import 'call_page.dart';
import 'widgets.dart';

/// PAGE 6 — 1:1 and group chat.
class ChatRoomPage extends ConsumerStatefulWidget {
  final String chatId, name; final Uint8List? dp; final bool isGroup;
  const ChatRoomPage({super.key, required this.chatId, required this.name, this.dp, required this.isGroup});
  @override ConsumerState<ChatRoomPage> createState() => _ChatState();
}
class _ChatState extends ConsumerState<ChatRoomPage> {
  final input = TextEditingController(), scroll = ScrollController(), rec = AudioRecorder();
  bool recording = false, hasText = false;

  @override void initState() { super.initState(); WidgetsBinding.instance.addPostFrameCallback((_) => ref.read(meshProvider).markRead(widget.chatId)); }

  Future<Map<String, bool>> _perm() async {
    if (!widget.isGroup) return {'send': true, 'call': true};
    final g = (await DatabaseHelper.I.groups()).firstWhere((g) => g['id'] == widget.chatId);
    final p = await DatabaseHelper.I.perms(widget.chatId);
    final admin = g['admin'] == IdentityService.I.id;
    return {'send': admin || p?['members_send'] == 1, 'call': admin || p?['members_call'] == 1, 'admin': admin};
  }

  @override
  Widget build(BuildContext context) {
    final m = ref.watch(meshProvider); final dark = Theme.of(context).brightness == Brightness.dark;
    return FutureBuilder(future: _perm(), builder: (_, ps) {
      final perm = ps.data ?? {'send': true, 'call': true};
      return Scaffold(
        appBar: AppBar(
          title: InkWell(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) =>
              InfoPage(chatId: widget.chatId, name: widget.name, isGroup: widget.isGroup))),
            child: Row(children: [Avatar(bytes: widget.dp, name: widget.name, r: 18), const SizedBox(width: 10), Expanded(child: Text(widget.name, overflow: TextOverflow.ellipsis))])),
          actions: [
            IconButton(icon: const Icon(Icons.call), onPressed: perm['call']! && !widget.isGroup ? () => _call(false) : null),
            IconButton(icon: const Icon(Icons.videocam), onPressed: perm['call']! && !widget.isGroup ? () => _call(true) : null),
          ]),
        body: Container(color: AppTheme.chatBg(dark), child: Column(children: [
          Expanded(child: FutureBuilder(
            key: ValueKey(m.hashCode ^ DateTime.now().millisecondsSinceEpoch ~/ 700),
            future: DatabaseHelper.I.messages(widget.chatId), builder: (_, s) {
              final msgs = s.data ?? [];
              return ListView.builder(controller: scroll, padding: const EdgeInsets.all(8), itemCount: msgs.length, itemBuilder: (_, i) => _bubble(msgs[i], dark));
            })),
          perm['send']! ? _inputBar(m) : Container(width: double.infinity, padding: const EdgeInsets.all(14),
              color: dark ? const Color(0xFF202C33) : Colors.white, child: const Text('Only admins can send messages', textAlign: TextAlign.center)),
        ])));
    });
  }

  Future<void> _call(bool video) async {
    await ref.read(meshProvider).rtc.initRenderers();
    if (mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => CallPage(peerId: widget.chatId, peerName: widget.name, video: video)));
  }

  Widget _bubble(Map<String, Object?> m, bool dark) {
    final mine = m['mine'] == 1; final state = m['state'] as int;
    final kind = m['kind'] as String;
    Widget content;
    if (kind == 'image' && m['file_path'] != null) { content = ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.file(File(m['file_path'] as String), width: 220)); }
    else if (kind == 'voice') { content = const Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.mic), SizedBox(width: 6), Text('Voice note')]); }
    else if (kind == 'file') { content = Row(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.insert_drive_file), const SizedBox(width: 6), Flexible(child: Text(m['body'] as String))]); }
    else { content = Text(m['body'] as String); }
    return Align(alignment: mine ? Alignment.centerRight : Alignment.centerLeft, child: Container(
      margin: const EdgeInsets.symmetric(vertical: 2), padding: const EdgeInsets.fromLTRB(10, 6, 10, 4),
      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .78),
      decoration: BoxDecoration(color: mine ? AppTheme.outBubble(dark) : AppTheme.inBubble(dark), borderRadius: BorderRadius.circular(10)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
        if (widget.isGroup && !mine) Text(m['sender_name'] as String, style: const TextStyle(fontSize: 12, color: AppTheme.green, fontWeight: FontWeight.bold)),
        content,
        Row(mainAxisSize: MainAxisSize.min, children: [
          Text(hhmm(m['ts'] as int), style: const TextStyle(fontSize: 10)),
          if (mine) ...[const SizedBox(width: 4), Icon(state == 0 ? Icons.check : Icons.done_all, size: 14, color: state == 2 ? Colors.blue : Colors.grey)],
        ]),
      ])));
  }

  Widget _inputBar(dynamic m) => SafeArea(child: Padding(padding: const EdgeInsets.all(6), child: Row(children: [
    Expanded(child: TextField(controller: input, minLines: 1, maxLines: 4, onChanged: (v) => setState(() => hasText = v.trim().isNotEmpty),
      decoration: InputDecoration(filled: true, hintText: 'Message', border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
        prefixIcon: IconButton(icon: const Icon(Icons.add), onPressed: _attach)))),
    const SizedBox(width: 6),
    CircleAvatar(backgroundColor: AppTheme.teal, child: hasText
        ? IconButton(icon: const Icon(Icons.send, color: Colors.white), onPressed: () async {
            final t = input.text.trim(); input.clear(); setState(() => hasText = false);
            await m.sendMessage(widget.chatId, widget.isGroup, t); setState(() {});
          })
        : IconButton(icon: Icon(recording ? Icons.stop : Icons.mic, color: Colors.white), onPressed: _toggleRec)),
  ])));

  Future<void> _attach() async {
    final r = await FilePicker.platform.pickFiles(withData: true); if (r == null) return;
    final f = r.files.first; if (f.bytes == null) return;
    if (f.bytes!.length > 3 * 1024 * 1024) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Max 3 MB per file over mesh'))); return; }
    final isImg = ['jpg', 'jpeg', 'png', 'webp'].contains(f.extension?.toLowerCase());
    await ref.read(meshProvider).sendMessage(widget.chatId, widget.isGroup, f.name, kind: isImg ? 'image' : 'file', file: f.bytes, fileName: f.name);
    setState(() {});
  }

  Future<void> _toggleRec() async {
    if (!recording) {
      if (!await rec.hasPermission()) return;
      final dir = await getTemporaryDirectory();
      await rec.start(const RecordConfig(encoder: AudioEncoder.aacLc, bitRate: 32000), path: '${dir.path}/vn_${DateTime.now().millisecondsSinceEpoch}.m4a');
      setState(() => recording = true);
    } else {
      final path = await rec.stop(); setState(() => recording = false);
      if (path != null) {
        final b = await File(path).readAsBytes();
        await ref.read(meshProvider).sendMessage(widget.chatId, widget.isGroup, 'Voice note', kind: 'voice', file: b, fileName: 'voice.m4a');
        setState(() {});
      }
    }
  }
}

/// Group Info / Friend profile; admin toggles permissions live.
class InfoPage extends ConsumerStatefulWidget {
  final String chatId, name; final bool isGroup;
  const InfoPage({super.key, required this.chatId, required this.name, required this.isGroup});
  @override ConsumerState<InfoPage> createState() => _InfoState();
}
class _InfoState extends ConsumerState<InfoPage> {
  @override
  Widget build(BuildContext context) {
    if (!widget.isGroup) {
      return Scaffold(appBar: AppBar(title: Text(widget.name)), body: FutureBuilder(
        future: DatabaseHelper.I.friends(status: 'accepted'), builder: (_, s) {
          final f = (s.data ?? []).where((f) => f['id'] == widget.chatId);
          if (f.isEmpty) return const SizedBox();
          return Column(children: [const SizedBox(height: 24), Center(child: Avatar(bytes: f.first['dp'] as Uint8List?, name: widget.name, r: 60)),
            const SizedBox(height: 12), Text(widget.name, style: const TextStyle(fontSize: 22)), Text((f.first['bio'] ?? '') as String)]);
        }));
    }
    return Scaffold(appBar: AppBar(title: Text(widget.name)), body: FutureBuilder(
      future: Future.wait([DatabaseHelper.I.perms(widget.chatId), DatabaseHelper.I.groups(), DatabaseHelper.I.friends(status: 'accepted')]),
      builder: (_, s) {
        if (!s.hasData) return const SizedBox();
        final p = s.data![0] as Map?; final g = (s.data![1] as List).firstWhere((g) => g['id'] == widget.chatId);
        final friends = s.data![2] as List; final admin = g['admin'] == IdentityService.I.id;
        bool add = p?['members_add'] == 1, send = p?['members_send'] == 1, call = p?['members_call'] == 1;
        Future<void> upd({bool? a, bool? se, bool? c}) async {
          await ref.read(meshProvider).updatePermissions(widget.chatId, add: a ?? add, send: se ?? send, call: c ?? call); setState(() {});
        }
        return ListView(children: [
          SwitchListTile(title: const Text('Members can add friends'), value: add, onChanged: admin ? (v) => upd(a: v) : null),
          SwitchListTile(title: const Text('Members can send messages'), value: send, onChanged: admin ? (v) => upd(se: v) : null),
          SwitchListTile(title: const Text('Members can start calls'), value: call, onChanged: admin ? (v) => upd(c: v) : null),
          if (!admin) const Padding(padding: EdgeInsets.all(12), child: Text('Only the admin can change these.')),
          if (admin || add) ...[const Divider(), const ListTile(title: Text('Add a friend')),
            for (final f in friends) ListTile(leading: Avatar(bytes: f['dp'] as Uint8List?, name: f['username'] as String), title: Text(f['username'] as String),
              trailing: IconButton(icon: const Icon(Icons.person_add), onPressed: () => ref.read(meshProvider).addMemberToGroup(widget.chatId, f['id'] as String)))],
        ]);
      }));
  }
}
