import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import '../main.dart';
import '../services/background_tower.dart';
import '../services/identity_service.dart';
import '../services/mesh_controller.dart';
import 'home_page.dart';
import 'widgets.dart';

/// PAGE 1
class OnboardingNamePage extends StatefulWidget {
  const OnboardingNamePage({super.key});
  @override State<OnboardingNamePage> createState() => _S1();
}
class _S1 extends State<OnboardingNamePage> {
  late final c = TextEditingController(text: IdentityService.I.username);
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Padding(padding: const EdgeInsets.all(24), child: Column(
      mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.hub, size: 80, color: Color(0xFF25D366)),
        const SizedBox(height: 16),
        const Text('Choose your mesh identity', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 24),
        TextField(controller: c, decoration: InputDecoration(labelText: 'Username', border: const OutlineInputBorder(),
          suffixIcon: IconButton(tooltip: 'Regenerate', icon: const Icon(Icons.refresh),
            onPressed: () => setState(() => c.text = IdentityService.randomUsername())))),
        const SizedBox(height: 24),
        SizedBox(width: double.infinity, child: FilledButton(onPressed: () async {
          final n = c.text.trim();
          if (n.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Username required'))); return; }
          await IdentityService.I.saveProfile(name: n);
          if (context.mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => const OnboardingProfilePage()));
        }, child: const Text('Next'))),
      ]))));
}

/// PAGE 2
class OnboardingProfilePage extends ConsumerStatefulWidget {
  const OnboardingProfilePage({super.key});
  @override ConsumerState<OnboardingProfilePage> createState() => _S2();
}
class _S2 extends ConsumerState<OnboardingProfilePage> {
  final bio = TextEditingController(); Uint8List? dp; bool busy = false;

  Future<void> pick() async {
    final src = await showModalBottomSheet<ImageSource>(context: context, builder: (_) => SafeArea(child: Wrap(children: [
      ListTile(leading: const Icon(Icons.camera_alt), title: const Text('Camera'), onTap: () => Navigator.pop(context, ImageSource.camera)),
      ListTile(leading: const Icon(Icons.photo), title: const Text('Gallery'), onTap: () => Navigator.pop(context, ImageSource.gallery)),
    ])));
    if (src == null) return;
    final x = await ImagePicker().pickImage(source: src); if (x == null) return;
    final b = await MeshController.compressDp(x.path);   // 256x256 WebP < 40KB
    setState(() => dp = b);
  }

  Future<void> finish({required bool skip}) async {
    setState(() => busy = true);
    await IdentityService.I.saveProfile(newBio: skip ? '' : bio.text.trim(), newDp: skip ? null : dp, finish: true);
    final m = ref.read(meshProvider);
    await m.startMesh(); await setTowerService(true);
    if (mounted) Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const HomePage()), (_) => false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Profile')),
    body: Padding(padding: const EdgeInsets.all(24), child: Column(children: [
      GestureDetector(onTap: pick, child: Stack(alignment: Alignment.bottomRight, children: [
        Avatar(bytes: dp, name: IdentityService.I.username, r: 56),
        const CircleAvatar(radius: 16, backgroundColor: Color(0xFF25D366), child: Icon(Icons.camera_alt, size: 16, color: Colors.white)),
      ])),
      if (dp != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text('${(dp!.length / 1024).toStringAsFixed(1)} KB WebP')),
      const SizedBox(height: 24),
      TextField(controller: bio, decoration: const InputDecoration(border: OutlineInputBorder(),
          labelText: 'Bio (optional)', hintText: 'Hey there! I am using Offline Mesh')),
      const Spacer(),
      if (busy) const CircularProgressIndicator() else Row(children: [
        Expanded(child: OutlinedButton(onPressed: () => finish(skip: true), child: const Text('Skip'))),
        const SizedBox(width: 12),
        Expanded(child: FilledButton(onPressed: () => finish(skip: false), child: const Text('Finish / Start'))),
      ]),
    ])));
}
