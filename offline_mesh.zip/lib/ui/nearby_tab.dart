import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/database_helper.dart';
import '../main.dart';
import 'widgets.dart';

/// PAGE 4 — Dual-phone radar, search, requests, discovered peers.
class NearbyTab extends ConsumerStatefulWidget {
  const NearbyTab({super.key});
  @override ConsumerState<NearbyTab> createState() => _NearbyState();
}
class _NearbyState extends ConsumerState<NearbyTab> with SingleTickerProviderStateMixin {
  late final AnimationController ac = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat();
  String q = '';
  @override void dispose() { ac.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final m = ref.watch(meshProvider);
    return FutureBuilder(
      future: DatabaseHelper.I.friends(), builder: (_, snap) {
        final friends = {for (final f in snap.data ?? []) f['id'] as String: f['status'] as String};
        final peers = m.discovered.where((p) => p.name.toLowerCase().contains(q.toLowerCase())
            && friends[p.id] != 'accepted').toList();
        return ListView(children: [
          SizedBox(height: 170, child: AnimatedBuilder(animation: ac,
              builder: (_, __) => CustomPaint(painter: _DualPhonePainter(ac.value, Theme.of(context).colorScheme.secondary)))),
          Center(child: Text(m.started ? 'Scanning • ${m.link.connected.length} linked' : 'Mesh offline')),
          Padding(padding: const EdgeInsets.all(12), child: TextField(onChanged: (v) => setState(() => q = v),
              decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search mesh by username',
                  border: OutlineInputBorder()))),
          if (m.incomingRequests.isNotEmpty) ...[
            const Padding(padding: EdgeInsets.all(12), child: Text('Friend requests', style: TextStyle(fontWeight: FontWeight.bold))),
            for (final r in m.incomingRequests.values) ListTile(
              leading: Avatar(name: r.srcName), title: Text(r.srcName), subtitle: Text(r.payload['bio'] ?? ''),
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                TextButton(onPressed: () => m.rejectRequest(r.src), child: const Text('Reject')),
                FilledButton(onPressed: () => m.acceptRequest(r.src), child: const Text('Accept')),
              ])),
          ],
          const Padding(padding: EdgeInsets.all(12), child: Text('Discovered peers', style: TextStyle(fontWeight: FontWeight.bold))),
          if (peers.isEmpty) const Padding(padding: EdgeInsets.all(24), child: Center(child: Text('No peers yet. Keep the app open near others.'))),
          for (final p in peers) ListTile(
            leading: Avatar(name: p.name), title: Text(p.name), subtitle: Text(hopLabel(p.hops)),
            trailing: m.pendingOut.contains(p.id) || friends[p.id] == 'pending_out'
                ? const Chip(label: Text('Pending'))
                : FilledButton(onPressed: () => m.sendFriendRequest(p.id, p.name), child: const Text('Send Request'))),
        ]);
      });
  }
}

class _DualPhonePainter extends CustomPainter {
  final double t; final Color c;
  _DualPhonePainter(this.t, this.c);
  @override
  void paint(Canvas cv, Size s) {
    final y = s.height / 2, lx = s.width * .22, rx = s.width * .78;
    void phone(double x) {
      final r = RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(x, y), width: 46, height: 82), const Radius.circular(8));
      cv.drawRRect(r, Paint()..color = Colors.grey.shade800);
      cv.drawRRect(r.deflate(4), Paint()..color = Colors.grey.shade300);
    }
    // pulsing waves from each phone
    for (final x in [lx, rx]) {
      for (var i = 0; i < 3; i++) {
        final p = (t + i / 3) % 1;
        cv.drawCircle(Offset(x, y), 30 + p * 45, Paint()..style = PaintingStyle.stroke..strokeWidth = 2
          ..color = c.withOpacity((1 - p) * .6));
      }
    }
    phone(lx); phone(rx);
    // data packets moving both ways
    for (var i = 0; i < 4; i++) {
      final p = (t + i / 4) % 1;
      final dir = i.isEven ? p : 1 - p;
      final x = lx + 30 + (rx - lx - 60) * dir;
      cv.drawCircle(Offset(x, y + sin((t + i) * 2 * pi) * 6), 4, Paint()..color = c);
    }
  }
  @override bool shouldRepaint(_DualPhonePainter o) => true;
}
