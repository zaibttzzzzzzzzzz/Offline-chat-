import 'dart:typed_data';
import 'package:flutter/material.dart';
import '../core/theme.dart';

class Avatar extends StatelessWidget {
  final Uint8List? bytes; final String name; final double r;
  const Avatar({super.key, this.bytes, required this.name, this.r = 24});
  @override
  Widget build(BuildContext c) => CircleAvatar(radius: r, backgroundColor: AppTheme.teal.withOpacity(.25),
      backgroundImage: bytes != null && bytes!.isNotEmpty ? MemoryImage(bytes!) : null,
      child: bytes == null || bytes!.isEmpty
          ? Text(name.isEmpty ? '?' : name[0].toUpperCase(), style: TextStyle(fontSize: r * .8)) : null);
}

String hhmm(int ts) {
  final d = DateTime.fromMillisecondsSinceEpoch(ts);
  return '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
}

String hopLabel(int hops) => hops <= 1 ? 'Direct • in range' : '${hops - 1} Tower${hops > 2 ? 's' : ''} away';
