import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/database_helper.dart';
import '../main.dart';
import '../services/identity_service.dart';
import 'call_page.dart';
import 'chat_room_page.dart';
import 'create_group_page.dart';
import 'nearby_tab.dart';
import 'settings_page.dart';
import 'updates_tab.dart';
import 'widgets.dart';

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});
  @override ConsumerState<HomePage> createState() => _HomeState();
}
class _HomeState extends ConsumerState<HomePage> {
  int tab = 0; bool searching = false; String q = '';
  static const titles = ['Offline Mesh', 'Updates', 'Nearby', 'Calls'];

  @override
  Widget build(BuildContext context) {
    final m = ref.watch(meshProvider);
    ref.listen(meshProvider.select((m) => m.incomingCall), (_, call) {
      if (call != null) {
        Navigator.push(context, MaterialPageRoute(builder: (_) => CallPage(peerId: call.src, peerName: call.srcName,
            video: call.payload['video'] == true, incoming: call)));
      }
    });
    final pages = [ChatsTab(query: q), const UpdatesTab(), const NearbyTab(), const _CallsTab()];
    return Scaffold(
      appBar: AppBar(
        title: searching
            ? TextField(autofocus: true, style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(hintText: 'Search…', border: InputBorder.none, hintStyle: TextStyle(color: Colors.white70)),
                onChanged: (v) => setState(() => q = v))
            : Text(titles[tab]),
        actions: [
          IconButton(icon: Icon(searching ? Icons.close : Icons.search), onPressed: () => setState(() { searching = !searching; q = ''; })),
          PopupMenuButton<String>(onSelected: (v) {
            switch (v) {
              case 'group': Navigator.push(context, MaterialPageRoute(builder: (_) => const CreateGroupPage())); break;
              case 'channel': setState(() => tab = 1); showCreateChannelDialog(context, ref); break;
              case 'theme': m.setDark(!m.dark); break;
              case 'settings': Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsPage())); break;
            }
          }, itemBuilder: (_) => [
            const PopupMenuItem(value: 'group', child: Text('New Group')),
            const PopupMenuItem(value: 'channel', child: Text('New Channel')),
            PopupMenuItem(value: 'theme', child: Text(m.dark ? 'Light Mode' : 'Dark Mode')),
            const PopupMenuItem(value: 'settings', child: Text('Settings')),
          ]),
        ],
      ),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.chat), label: 'Chats'),
          NavigationDestination(icon: Icon(Icons.update), label: 'Updates'),
          NavigationDestination(icon: Icon(Icons.radar), label: 'Nearby'),
          NavigationDestination(icon: Icon(Icons.call), label: 'Calls'),
        ]),
    );
  }
}

/// PAGE 3 — accepted friends and joined groups only.
class ChatsTab extends ConsumerWidget {
  final String query;
  const ChatsTab({super.key, this.query = ''});
  Future<List<Map<String, dynamic>>> _load() async {
    final out = <Map<String, dynamic>>[];
    for (final f in await DatabaseHelper.I.friends(status: 'accepted')) {
      out.add({'id': f['id'], 'name': f['username'], 'dp': f['dp'], 'group': false});
    }
    for (final g in await DatabaseHelper.I.groups()) {
      out.add({'id': g['id'], 'name': g['name'], 'dp': g['icon'], 'group': true});
    }
    for (final c in out) {
      c['last'] = await DatabaseHelper.I.lastMessage(c['id']);
      c['unread'] = await DatabaseHelper.I.unread(c['id']);
    }
    out.sort((a, b) => ((b['last']?['ts'] ?? 0) as int).compareTo((a['last']?['ts'] ?? 0) as int));
    return query.isEmpty ? out : out.where((c) => (c['name'] as String).toLowerCase().contains(query.toLowerCase())
        || ((c['last']?['body'] ?? '') as String).toLowerCase().contains(query.toLowerCase())).toList();
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final m = ref.watch(meshProvider);
    return FutureBuilder(
      key: ValueKey(DateTime.now().millisecondsSinceEpoch ~/ 1000),
      future: _load(), builder: (_, snap) {
        final items = snap.data ?? [];
        if (items.isEmpty) return const Center(child: Padding(padding: EdgeInsets.all(32),
            child: Text('No chats yet.\nOpen the Nearby tab to find people and send friend requests.', textAlign: TextAlign.center)));
        return ListView.builder(itemCount: items.length, itemBuilder: (_, i) {
          final c = items[i]; final last = c['last'] as Map?;
          final hops = m.router.hopsTo(c['id']);
          return ListTile(
            leading: Stack(children: [Avatar(bytes: c['dp'] as Uint8List?, name: c['name']),
              if (!c['group']) Positioned(right: 0, bottom: 0, child: CircleAvatar(radius: 6,
                backgroundColor: hops == null ? Colors.grey : hops <= 1 ? Colors.green : Colors.orange))]),
            title: Text(c['name']), subtitle: Text(last == null ? '' : last['kind'] == 'text' ? last['body'] : '📎 ${last['kind']}', maxLines: 1, overflow: TextOverflow.ellipsis),
            trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
              if (last != null) Text(hhmm(last['ts']), style: const TextStyle(fontSize: 12)),
              if (c['unread'] > 0) CircleAvatar(radius: 10, backgroundColor: const Color(0xFF25D366),
                  child: Text('${c['unread']}', style: const TextStyle(fontSize: 11, color: Colors.white))),
            ]),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) =>
                ChatRoomPage(chatId: c['id'], name: c['name'], dp: c['dp'], isGroup: c['group']))),
          );
        });
      });
  }
}

class _CallsTab extends ConsumerWidget {
  const _CallsTab();
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final log = ref.watch(meshProvider).callLog;
    return log.isEmpty ? const Center(child: Text('No recent calls'))
        : ListView(children: [for (final l in log) ListTile(leading: const Icon(Icons.call_received), title: Text(l))]);
  }
}
