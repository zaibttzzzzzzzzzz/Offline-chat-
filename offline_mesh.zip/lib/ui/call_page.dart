import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import '../core/packet.dart';
import '../main.dart';
import 'widgets.dart';

/// PAGE 7 — serverless WebRTC call (iceServers: []), signaling over mesh.
class CallPage extends ConsumerStatefulWidget {
  final String peerId, peerName; final bool video; final Packet? incoming;
  const CallPage({super.key, required this.peerId, required this.peerName, required this.video, this.incoming});
  @override ConsumerState<CallPage> createState() => _CallState();
}
class _CallState extends ConsumerState<CallPage> {
  bool muted = false, speaker = false, connected = false, ready = false;
  Offset pip = const Offset(16, 60); String status = 'Calling…';

  @override void initState() { super.initState(); _start(); }

  Future<void> _start() async {
    final m = ref.read(meshProvider);
    await m.rtc.initRenderers();
    m.rtc.onState = (s) { if (mounted) setState(() { status = s; connected = s == 'RTCPeerConnectionStateConnected'; }); };
    if (widget.incoming != null) { status = 'Connecting…'; await m.rtc.acceptOffer(widget.incoming!); }
    else { await m.rtc.startCall(widget.peerId, video: widget.video); }
    await m.rtc.setSpeaker(widget.video);
    speaker = widget.video;
    if (mounted) setState(() => ready = true);
  }

  Future<void> _end() async {
    final m = ref.read(meshProvider);
    await m.rtc.end(); m.incomingCall = null;
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final rtc = ref.read(meshProvider).rtc;
    return PopScope(canPop: false, onPopInvoked: (_) => _end(), child: Scaffold(
      backgroundColor: Colors.black,
      body: Stack(children: [
        if (widget.video && ready) Positioned.fill(child: RTCVideoView(rtc.remoteRenderer, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover))
        else Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
          Avatar(name: widget.peerName, r: 64), const SizedBox(height: 16),
          Text(widget.peerName, style: const TextStyle(color: Colors.white, fontSize: 24)),
          Text(status, style: const TextStyle(color: Colors.white70))])),
        if (widget.video && ready) Positioned(left: pip.dx, top: pip.dy, child: GestureDetector(
          onPanUpdate: (d) => setState(() => pip += d.delta),
          child: SizedBox(width: 110, height: 150, child: ClipRRect(borderRadius: BorderRadius.circular(10),
            child: RTCVideoView(rtc.localRenderer, mirror: true, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover))))),
        Positioned(bottom: 40, left: 0, right: 0, child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          _btn(muted ? Icons.mic_off : Icons.mic, () { setState(() => muted = !muted); rtc.setMute(muted); }),
          _btn(speaker ? Icons.volume_up : Icons.hearing, () { setState(() => speaker = !speaker); rtc.setSpeaker(speaker); }),
          if (widget.video) _btn(Icons.cameraswitch, rtc.switchCamera),
          _btn(Icons.call_end, _end, color: Colors.red),
        ])),
      ])));
  }

  Widget _btn(IconData i, VoidCallback f, {Color color = Colors.white24}) => CircleAvatar(radius: 28, backgroundColor: color,
      child: IconButton(icon: Icon(i, color: Colors.white), onPressed: f));
}
