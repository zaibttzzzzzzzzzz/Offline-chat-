import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import '../main.dart';
import '../services/background_tower.dart';
import '../services/identity_service.dart';
import '../services/mesh_controller.dart';
import 'widgets.dart';

/// PAGE 9 — Settings & Tower control.
class SettingsPage extends ConsumerStatefulWidget {
  const SettingsPage({super.key});
  @override ConsumerState<SettingsPage> createState() => _SetState();
}
class _SetState extends ConsumerState<SettingsPage> {
  final id = IdentityService.I;
  @override
  Widget build(BuildContext context) {
    final m = ref.watch(meshProvider);
    return Scaffold(appBar: AppBar(title: const Text('Settings')), body: ListView(children: [
      Card(margin: const EdgeInsets.all(12), child: ListTile(
        leading: Avatar(bytes: id.dp, name: id.username, r: 30), title: Text(id.username), subtitle: Text(id.bio.isEmpty ? 'Hey there! I am using Offline Mesh' : id.bio),
        trailing: const Icon(Icons.edit), onTap: _edit)),
      SwitchListTile(title: const Text('Dark mode'), value: m.dark, onChanged: m.setDark),
      SwitchListTile(title: const Text('Tower Relay Mode'), subtitle: const Text('Forward packets for other users (foreground service)'),
        value: m.tower, onChanged: (v) async { await m.setTower(v); await setTowerService(v); }),
      ListTile(title: const Text('Mesh status'), subtitle: Text('${m.link.connected.length} direct links • ${m.router.routing.length} known nodes')),
    ]));
  }

  Future<void> _edit() async {
    final n = TextEditingController(text: id.username), b = TextEditingController(text: id.bio);
    await showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Edit profile'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: n, decoration: const InputDecoration(labelText: 'Username')),
        TextField(controller: b, decoration: const InputDecoration(labelText: 'Bio')),
        TextButton.icon(icon: const Icon(Icons.photo), label: const Text('Change photo (<40KB WebP)'), onPressed: () async {
          final x = await ImagePicker().pickImage(source: ImageSource.gallery); if (x == null) return;
          await id.saveProfile(newDp: await MeshController.compressDp(x.path));
        })]),
      actions: [FilledButton(onPressed: () async {
        await id.saveProfile(name: n.text.trim(), newBio: b.text.trim());
        await ref.read(meshProvider).broadcastProfile(); if (mounted) { Navigator.pop(context); setState(() {}); }
      }, child: const Text('Save'))]));
  }
}
