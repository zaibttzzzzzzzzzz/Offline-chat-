import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import '../data/database_helper.dart';
import '../main.dart';
import '../services/mesh_controller.dart';
import 'widgets.dart';

/// PAGE 5 — Step 1 member selection, Step 2 setup + admin permissions.
class CreateGroupPage extends StatefulWidget {
  const CreateGroupPage({super.key});
  @override State<CreateGroupPage> createState() => _CGState();
}
class _CGState extends State<CreateGroupPage> {
  final selected = <String>{};
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Add participants')),
    floatingActionButton: FloatingActionButton(
      onPressed: selected.isEmpty ? null : () => Navigator.push(context, MaterialPageRoute(builder: (_) => GroupSetupPage(members: selected.toList()))),
      child: const Icon(Icons.arrow_forward)),
    body: FutureBuilder(future: DatabaseHelper.I.friends(status: 'accepted'), builder: (_, s) {
      final f = s.data ?? [];
      if (f.isEmpty) return const Center(child: Text('Accept friends first (Nearby tab).'));
      return ListView(children: [for (final x in f) CheckboxListTile(
        value: selected.contains(x['id']), title: Text(x['username'] as String),
        secondary: Avatar(bytes: x['dp'] as Uint8List?, name: x['username'] as String),
        onChanged: (v) => setState(() => v! ? selected.add(x['id'] as String) : selected.remove(x['id'])))]);
    }));
}

class GroupSetupPage extends ConsumerStatefulWidget {
  final List<String> members;
  const GroupSetupPage({super.key, required this.members});
  @override ConsumerState<GroupSetupPage> createState() => _GSState();
}
class _GSState extends ConsumerState<GroupSetupPage> {
  final name = TextEditingController(); Uint8List? icon;
  bool add = false, send = true, call = true;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('New group')),
    floatingActionButton: FloatingActionButton(child: const Icon(Icons.check), onPressed: () async {
      if (name.text.trim().isEmpty) return;
      await ref.read(meshProvider).createGroup(name.text.trim(), widget.members, add: add, send: send, call: call, icon: icon);
      if (context.mounted) Navigator.popUntil(context, (r) => r.isFirst);
    }),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Row(children: [
        GestureDetector(onTap: () async {
          final x = await ImagePicker().pickImage(source: ImageSource.gallery); if (x == null) return;
          icon = await MeshController.compressDp(x.path); setState(() {});
        }, child: Avatar(bytes: icon, name: name.text, r: 30)),
        const SizedBox(width: 16),
        Expanded(child: TextField(controller: name, decoration: const InputDecoration(labelText: 'Group name'))),
      ]),
      const SizedBox(height: 24),
      const Text('Admin permissions (signed)', style: TextStyle(fontWeight: FontWeight.bold)),
      SwitchListTile(title: const Text('Allow members to add friends'), subtitle: const Text('OFF: only admin adds members'),
          value: add, onChanged: (v) => setState(() => add = v)),
      SwitchListTile(title: const Text('Allow members to send messages'), subtitle: const Text('OFF: admin-only announcements'),
          value: send, onChanged: (v) => setState(() => send = v)),
      SwitchListTile(title: const Text('Allow members to start calls'), subtitle: const Text('OFF: only admin can call'),
          value: call, onChanged: (v) => setState(() => call = v)),
    ]));
}
