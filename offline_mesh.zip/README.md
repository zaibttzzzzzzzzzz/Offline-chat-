# Offline Mesh (Flutter)
1. `flutter create . --org com.offlinemesh --platforms android` (generates gradle/Kotlin files; keep the provided lib/, pubspec.yaml, then re-apply AndroidManifest.xml from this repo)
2. In android/app/build.gradle: `minSdkVersion 26`, `compileSdkVersion 34+`.
3. `flutter pub get && flutter run` on 2+ physical Android devices (emulators have no BLE/Wi-Fi Direct).
Status: scaffold, not compiled/tested. Expect to fix minor API drift between package versions.
